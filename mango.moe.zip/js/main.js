
            var SPE_USES_PREVIEW_IMAGE = false;
            const runtime = new SpeRuntime( SPLINE_EXPORTED_SCENE, SPLINE_ASSETS_LIST );
            runtime.run();
        